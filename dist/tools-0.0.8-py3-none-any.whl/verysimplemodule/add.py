class add:
    def add(number):
        return number + 1
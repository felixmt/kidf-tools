# kidf-tools
how to install libraries as pip package from other projects :
python3 -m pip install -e git+ssh://git@github.com/felixmt/kidf-tools.git#egg=verysimplemodule
def add(number):
    return number + 1
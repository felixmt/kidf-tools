class add:
    def add(self, number):
        return number + 1